<?php
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP (leave empty)
$dbname = "employee_management";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insert'])) {
        $employee_name = $_POST['employee_name'];
        $employee_id = $_POST['employee_id'];
        $department_name = $_POST['department_name'];
        $phone_number = $_POST['phone_number'];
        $joining_date = $_POST['joining_date'];

        $sql = "INSERT INTO employees (employee_name, employee_id, department_name, phone_number, joining_date)
                VALUES ('$employee_name', '$employee_id', '$department_name', '$phone_number', '$joining_date')";

        if ($conn->query($sql) === TRUE) {
            echo "New employee inserted successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['delete'])) {
        $employee_id = $_POST['employee_id'];
        $sql = "DELETE FROM employees WHERE employee_id='$employee_id'";

        if ($conn->query($sql) === TRUE) {
            echo "Employee deleted successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    if (isset($_POST['update'])) {
        $employee_id = $_POST['employee_id'];
        $employee_name = $_POST['employee_name'];
        $department_name = $_POST['department_name'];
        $phone_number = $_POST['phone_number'];
        $joining_date = $_POST['joining_date'];

        $sql = "UPDATE employees SET employee_name='$employee_name', department_name='$department_name', phone_number='$phone_number', joining_date='$joining_date' WHERE employee_id='$employee_id'";

        if ($conn->query($sql) === TRUE) {
            echo "Employee updated successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    if (isset($_POST['view'])) {
        $sql = "SELECT * FROM employees";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table border='1'><tr><th>Employee Name</th><th>Employee ID</th><th>Department Name</th><th>Phone Number</th><th>Joining Date</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['employee_name']}</td><td>{$row['employee_id']}</td><td>{$row['department_name']}</td><td>{$row['phone_number']}</td><td>{$row['joining_date']}</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No records found.";
        }
    }
}

$conn->close();
?>
