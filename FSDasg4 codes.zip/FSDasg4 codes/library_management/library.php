<?php
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP (leave empty)
$dbname = "library_management";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insert'])) {
        $book_name = $_POST['book_name'];
        $isbn_no = $_POST['isbn_no'];
        $book_title = $_POST['book_title'];
        $author_name = $_POST['author_name'];
        $publisher_name = $_POST['publisher_name'];

        $sql = "INSERT INTO books (book_name, isbn_no, book_title, author_name, publisher_name)
                VALUES ('$book_name', '$isbn_no', '$book_title', '$author_name', '$publisher_name')";

        if ($conn->query($sql) === TRUE) {
            echo "New book inserted successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['delete'])) {
        $isbn_no = $_POST['isbn_no'];
        $sql = "DELETE FROM books WHERE isbn_no='$isbn_no'";

        if ($conn->query($sql) === TRUE) {
            echo "Book deleted successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    if (isset($_POST['update'])) {
        $isbn_no = $_POST['isbn_no'];
        $book_name = $_POST['book_name'];
        $book_title = $_POST['book_title'];
        $author_name = $_POST['author_name'];
        $publisher_name = $_POST['publisher_name'];

        $sql = "UPDATE books SET book_name='$book_name', book_title='$book_title', author_name='$author_name', publisher_name='$publisher_name' WHERE isbn_no='$isbn_no'";

        if ($conn->query($sql) === TRUE) {
            echo "Book updated successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    if (isset($_POST['view'])) {
        $sql = "SELECT * FROM books";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table border='1'><tr><th>Book Name</th><th>ISBN No</th><th>Book Title</th><th>Author Name</th><th>Publisher Name</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['book_name']}</td><td>{$row['isbn_no']}</td><td>{$row['book_title']}</td><td>{$row['author_name']}</td><td>{$row['publisher_name']}</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No records found.";
        }
    }
}

$conn->close();
?>
