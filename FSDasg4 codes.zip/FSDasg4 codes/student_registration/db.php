<?php
$servername = "localhost";
$username = "root"; // Replace with your DB username
$password = ""; // Replace with your DB password
$dbname = "student_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Email Configuration
define('EMAIL_FROM', 'your-email@example.com'); // Replace with your email
define('EMAIL_SUBJECT', 'Student Registration Confirmation');
?>
