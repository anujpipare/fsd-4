<?php
include 'db.php';
session_start();

$success_message = "";
$error_message = "";

// Send Email Function
function sendEmail($to, $subject, $message) {
    $headers = "From: " . EMAIL_FROM . "\r\n";
    mail($to, $subject, $message, $headers);
}

// Insert operation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['insert'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $roll_no = trim($_POST['roll_no']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $contact_number = trim($_POST['contact_number']);
    $email = trim($_POST['email']); // Added email field

    if ($password !== $confirm_password) {
        $error_message = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO students (first_name, last_name, roll_no, password, contact_number, email) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $first_name, $last_name, $roll_no, $hashed_password, $contact_number, $email);
        if ($stmt->execute()) {
            sendEmail($email, EMAIL_SUBJECT, "Thank you for registering, $first_name!");
            $success_message = "Student registered successfully.";
        } else {
            $error_message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Delete operation
if (isset($_POST['delete'])) {
    $roll_no = trim($_POST['roll_no']);
    $stmt = $conn->prepare("DELETE FROM students WHERE roll_no = ?");
    $stmt->bind_param("s", $roll_no);
    if ($stmt->execute()) {
        $success_message = "Student deleted successfully.";
    } else {
        $error_message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Update operation
if (isset($_POST['update'])) {
    $roll_no = trim($_POST['roll_no']);
    $contact_number = trim($_POST['contact_number']);
    $stmt = $conn->prepare("UPDATE students SET contact_number = ? WHERE roll_no = ?");
    $stmt->bind_param("ss", $contact_number, $roll_no);
    if ($stmt->execute()) {
        $success_message = "Student details updated successfully.";
    } else {
        $error_message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Login operation
if (isset($_POST['login'])) {
    $roll_no = trim($_POST['roll_no']);
    $password = trim($_POST['password']);
    $stmt = $conn->prepare("SELECT password FROM students WHERE roll_no = ?");
    $stmt->bind_param("s", $roll_no);
    $stmt->execute();
    $stmt->bind_result($hashed_password);
    if ($stmt->fetch() && password_verify($password, $hashed_password)) {
        $_SESSION['roll_no'] = $roll_no;
        $success_message = "Login successful. Welcome back!";
    } else {
        $error_message = "Invalid Roll No or Password.";
    }
    $stmt->close();
}

// Password Recovery
if (isset($_POST['recover'])) {
    $roll_no = trim($_POST['roll_no']);
    $stmt = $conn->prepare("SELECT email FROM students WHERE roll_no = ?");
    $stmt->bind_param("s", $roll_no);
    $stmt->execute();
    $stmt->bind_result($email);
    if ($stmt->fetch()) {
        $token = bin2hex(random_bytes(50));
        $stmt = $conn->prepare("UPDATE students SET token = ? WHERE roll_no = ?");
        $stmt->bind_param("ss", $token, $roll_no);
        $stmt->execute();

        // Send recovery email
        $recovery_link = "http://localhost/student_registration/reset_password.php?token=$token"; // Adjusted for local testing
        sendEmail($email, "Password Recovery", "Reset your password by clicking here: $recovery_link");
        $success_message = "Recovery email sent.";
    } else {
        $error_message = "Roll No not found.";
    }
    $stmt->close();
}

// Read operation
$result = $conn->query("SELECT * FROM students");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration System</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body>
    <h1>Student Registration System</h1>

    <?php if ($success_message) echo "<p class='success'>$success_message</p>"; ?>
    <?php if ($error_message) echo "<p class='error'>$error_message</p>"; ?>

    <form id="registrationForm" method="POST">
        <input type="text" name="first_name" placeholder="First Name" required>
        <input type="text" name="last_name" placeholder="Last Name" required>
        <input type="text" name="roll_no" placeholder="Roll No/ID" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="text" name="contact_number" placeholder="Contact Number" required>
        <input type="email" name="email" placeholder="Email" required> <!-- New email field -->
        <button type="submit" name="insert">Register</button>
    </form>

    <form method="POST">
        <input type="text" name="roll_no" placeholder="Roll No/ID to Delete" required>
        <button type="submit" name="delete">Delete Student</button>
    </form>

    <form method="POST">
        <input type="text" name="roll_no" placeholder="Roll No/ID to Update" required>
        <input type="text" name="contact_number" placeholder="New Contact Number" required>
        <button type="submit" name="update">Update Student</button>
    </form>

    <h2>Login</h2>
    <form method="POST">
        <input type="text" name="roll_no" placeholder="Roll No/ID" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>

    <h2>Password Recovery</h2>
    <form method="POST">
        <input type="text" name="roll_no" placeholder="Roll No/ID" required>
        <button type="submit" name="recover">Recover Password</button>
    </form>

    <h2>Student Records</h2>
    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Roll No/ID</th>
            <th>Contact Number</th>
            <th>Email</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['roll_no']; ?></td>
            <td><?php echo $row['contact_number']; ?></td>
            <td><?php echo $row['email']; ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
