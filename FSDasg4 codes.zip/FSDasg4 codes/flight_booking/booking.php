<?php
$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP (leave empty)
$dbname = "flight_booking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insert'])) {
        $passenger_name = $_POST['passenger_name'];
        $from_location = $_POST['from_location'];
        $to_location = $_POST['to_location'];
        $flight_date = $_POST['flight_date'];
        $departure_date = $_POST['departure_date'];
        $arrival_date = $_POST['arrival_date'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email'];

        $sql = "INSERT INTO passengers (passenger_name, from_location, to_location, flight_date, departure_date, arrival_date, phone_number, email)
                VALUES ('$passenger_name', '$from_location', '$to_location', '$flight_date', '$departure_date', '$arrival_date', '$phone_number', '$email')";

        if ($conn->query($sql) === TRUE) {
            echo "New passenger inserted successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['delete'])) {
        $phone_number = $_POST['phone_number'];
        $sql = "DELETE FROM passengers WHERE phone_number='$phone_number'";

        if ($conn->query($sql) === TRUE) {
            echo "Passenger deleted successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    if (isset($_POST['update'])) {
        $phone_number = $_POST['phone_number'];
        $passenger_name = $_POST['passenger_name'];
        $from_location = $_POST['from_location'];
        $to_location = $_POST['to_location'];
        $flight_date = $_POST['flight_date'];
        $departure_date = $_POST['departure_date'];
        $arrival_date = $_POST['arrival_date'];
        $email = $_POST['email'];

        $sql = "UPDATE passengers SET passenger_name='$passenger_name', from_location='$from_location', to_location='$to_location', flight_date='$flight_date', departure_date='$departure_date', arrival_date='$arrival_date', email='$email' WHERE phone_number='$phone_number'";

        if ($conn->query($sql) === TRUE) {
            echo "Passenger updated successfully.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    if (isset($_POST['view'])) {
        $sql = "SELECT * FROM passengers";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table border='1'><tr><th>Passenger Name</th><th>From</th><th>To</th><th>Flight Date</th><th>Departure Date</th><th>Arrival Date</th><th>Phone Number</th><th>Email</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['passenger_name']}</td><td>{$row['from_location']}</td><td>{$row['to_location']}</td><td>{$row['flight_date']}</td><td>{$row['departure_date']}</td><td>{$row['arrival_date']}</td><td>{$row['phone_number']}</td><td>{$row['email']}</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No records found.";
        }
    }
}

$conn->close();
?>
